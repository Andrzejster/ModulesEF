<?php defined('EF5_SYSTEM') || exit;

return array(
	'Display status of the Gadu-Gadu' => 'Wy�wietla status u�ytkownika Gadu-Gadu'
);