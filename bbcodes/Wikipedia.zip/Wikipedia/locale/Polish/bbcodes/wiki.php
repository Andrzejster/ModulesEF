<?php defined('EF5_SYSTEM') || exit;

return array(
	'Search text in Wikipedia' => 'Wyszukuje tekstu w Wikipedii'
);