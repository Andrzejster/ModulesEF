<?php defined('EF5_SYSTEM') || exit;

return array(
	'Zippyshare Player' => 'Zippyshare hráč',
	'Plays music files on the Zippyshare player' => 'Hraje hudební soubory z Zippyshare přehrávače'
);