<?php defined('EF5_SYSTEM') || exit;

return array(
	'Zippyshare Player' => 'Odtwarzacz Zippyshare',
	'Plays music files on the Zippyshare player' => 'Odtwarza pliki muzyczne w odtwarzaczu Zippyshare'
);