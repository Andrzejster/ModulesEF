<?php defined('EF5_SYSTEM') || exit;

return array(
	'Google Search' => 'Vyhledávání Google',
	'Search text in the Google' => 'Hledat text ve vyhledávači Google'
);