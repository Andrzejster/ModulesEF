<?php defined('EF5_SYSTEM') || exit;

return array(
	'Google Search' => 'Wyszukiwarka Google',
	'Search text in the Google' => 'Wyszukuje tekstu w wyszukiwarce Google'
);