<?php defined('EF5_SYSTEM') || exit;

return array(
	'Displays video from YouTube' => 'Wyświetla film z portalu YouTube'
);