<?php defined('EF5_SYSTEM') || exit;

return array(
	'Displays video from YouTube' => 'Zobrazí video z YouTube'
);