<?php defined('EF5_SYSTEM') || exit;

return array(
	'Last seen users' => 'Naposledy viděn',
	'week' => 'týden',
	'weeks' => 'týdnů',
	'day' => 'den',
	'days' => 'dny',
	'Guest online' => 'Uživatelů online',
	'Total Members' => 'Celkem uživatelů'
);