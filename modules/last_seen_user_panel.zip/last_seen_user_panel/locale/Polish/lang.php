<?php defined('EF5_SYSTEM') || exit;

return array(
	'Last seen users' => 'Ostatnio widziani',
	'week' => 'tydzień',
	'weeks' => 'tygodnie',
	'day' => 'dzień',
	'days' => 'dni',
	'Guest online' => 'Gości online',
	'Total Members' => 'Łącznie użytkowników'
);