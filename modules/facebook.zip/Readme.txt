﻿Name: Facebook
Author: Andrzejster
http://extreme-fusion.org

Nie zezwalam na rozpowszechnianie modułu bez mojej zgody.
+++++++++++++++++++++++++++++
INSTALACJA:

Pliki po rozpakowaniu należy wgrać do katalogu modules/ i zainstalować, póżniej można włączyć panel facebooka (Zarządzanie panelami) lub korzystać wyłącznie z podstrony.