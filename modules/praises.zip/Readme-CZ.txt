Name: Pochwa�y (Praises)
Author: Andrzejster
http://extreme-fusion.org

Nie zezwalam na rozpowszechnianie modu�u bez mojej zgody.
+++++++++++++++++++++++++++++
INSTALACE:

Rozbalen� soubory nahrajte do adres��e /modules a nainstalujte v sekci moduly. Podstr�nka pochval pro konkr�tn�ho u�ivatele m� adresu:v�web/praises/{ID}.html

+++++++++++++++++++++++++++++
ZOBRAZEN� V PROFILU:

Aby se pochvaly zobrazily ve Va�em profilu, postupujte podle n�sleduj�c�ch pokyn�:

Najdi soubor PAGES/PROFILE.PHP:
Za ��dek ~196 p�idej n�sleduj�c� ��st k�du:

if ($_pdo->tableExists('praises'))
	{
		$query = $_pdo->getData('SELECT `id` FROM [praises] WHERE `user_id` = :id',
			array(':id', $row['id'], PDO::PARAM_INT)
		);
		$praises = array(
			'praises' => $_pdo->getRowsCount($query),
			'link' => $_route->path(array('controller' => 'praises', 'action' => $row['id']))
		);
		
		$_tpl->assign('praises', $praises);
	}

Najdi soubor TEMPLATES/PROFILE.TPL:
Za ��dek ~49 p�idej n�sleduj�c� ��st k�du:
{if $praises != 0}
                <p class="element light clearfix">
                    <strong class="text_other"><a href="{$praises.link}">Praises: </a></strong>
                    <span>{$praises.praises}</span>
                </p>
            {/if}