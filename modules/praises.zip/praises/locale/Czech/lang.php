<?php defined('EF5_SYSTEM') || exit;

return array(
	'Praises' => 'Pochvaly',
	'Praises user :username' => 'Pochvala uživatele :username',
	'This plugin allows you to add praises to users.' => 'Tento modul umožňuje uživatelům přidávat pochvaly.',
	//Profile
	'You have :how praises' => 'Přijatá pochvala: :how',
	'Back to profile' => 'Zpět do profilu',
);