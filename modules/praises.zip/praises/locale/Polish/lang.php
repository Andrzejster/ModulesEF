<?php defined('EF5_SYSTEM') || exit;

return array(
	'Praises' => 'Pochwały',
	'Praises user :username' => 'Pochwały użytkownika :username',
	'This plugin allows you to add praises to users.' => 'Wtyczka umożliwia dodawanie pochwał użytkownikom.',
	//Profile
	'You have :how praises' => 'Otrzymanych pochwał: :how',
	'Back to profile' => 'Wróć do profilu',
);